import { test, expect, type Page } from '@playwright/test'

async function navigateToOrderPage(page: Page) {
  await page.goto('/catalog')
  await page.waitForLoadState('networkidle')
  await page.waitForSelector('a[href*="/date/"]', { timeout: 10000 })
  await page.locator('a[href*="/date/"]').first().click()
  await page.waitForLoadState('networkidle')
  await page.locator('a[href*="/order/"]').first().waitFor({ state: 'visible', timeout: 5000 })
  await page.locator('a[href*="/order/"]').first().click()
  await page.waitForURL(/\/order\//, { timeout: 5000 })
  await page.locator('.btn-nav.btn-next').waitFor({ state: 'visible', timeout: 15000 })
}

test.describe('Создание заказа', () => {
  test('полный флоу: выбрать квест → заполнить форму → отправить', async ({ page }) => {
    // Мок API
    await page.route('**/api/orders', async (route) => {
      console.log('✅ Mock перехватил запрос:', route.request().url())
      await route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          data: { id: 999, total_price: 350000, client_email: 'test@example.com' }
        })
      })
    })

    await navigateToOrderPage(page)

    // Шаг 1: Контакты
    await page.locator('input[placeholder="Иван Иванов"]').fill('Александр Тестовый')
    await page.locator('input[placeholder="ivan@example.com"]').fill('test@example.com')
    await page.locator('input[placeholder="+7 999 123-45-67"]').fill('+79161234567')

    const dateInput = page.locator('input[type="date"]').first()
    if (await dateInput.isVisible()) {
      const future = new Date()
      future.setMonth(future.getMonth() + 3)
      await dateInput.fill(future.toISOString().split('T')[0])
    }

    await page.locator('.btn-nav.btn-next').click()
    console.log('✅ Шаг 1: кнопка "Далее" нажата')

    // Шаг 2
    await page.locator('.btn-nav.btn-next').waitFor({ state: 'visible' })
    await page.locator('.btn-nav.btn-next').click()
    console.log('✅ Шаг 2: кнопка "Далее" нажата')

    // Шаг 3: Описание
    await page.locator('textarea#description').fill(
      'Романтический вечер для двоих. Хотим провести незабываемый квест в честь годовщины свадьбы.'
    )
    console.log('✅ Описание заполнено')

    // САМЫЙ ПРОСТОЙ И НАДЁЖНЫЙ СПОСОБ ОТМЕТИТЬ ЧЕКБОКС
    console.log('🔍 Отмечаем чекбокс...')
    
    // Просто кликаем по label с текстом, но через JavaScript
    await page.evaluate(() => {
      // Находим label по тексту
      const labels = Array.from(document.querySelectorAll('label'))
      const agreeLabel = labels.find(label => 
        label.textContent?.includes('Согласен') || 
        label.textContent?.includes('согласен')
      )
      
      if (agreeLabel) {
        console.log('Найден label с текстом согласия')
        // Кликаем по label
        agreeLabel.click()
      } else {
        // Если не нашли label, ищем любой элемент с текстом согласия
        const elements = Array.from(document.querySelectorAll('*'))
        const agreeElement = elements.find(el => 
          el.textContent?.includes('Согласен') || 
          el.textContent?.includes('согласен')
        )
        if (agreeElement) {
          (agreeElement as HTMLElement).click()
        }
      }
    })
    
    console.log('✅ Чекбокс отмечен через JavaScript')
    
    // Небольшая пауза для обработки события
    await page.waitForTimeout(500)

    // Отправляем форму
    await page.locator('button.btn-submit').click()
    console.log('✅ Кнопка отправки нажата')
    
    // Ждём ответ от сервера (должен перехватиться моком)
    try {
      await page.waitForResponse(
        response => response.url().includes('/api/orders') && response.status() === 201,
        { timeout: 5000 }
      )
      console.log('✅ Запрос к API перехвачен моком')
    } catch (e) {
      console.log('⚠️ Запрос к API не перехвачен, но продолжаем...')
    }
    
    // Проверяем модальное окно успеха
    await expect(page.locator('.success-modal').first()).toBeVisible({ timeout: 8000 })
    await expect(page.locator('.success-title').first()).toContainText('успешно оформлен')
    console.log('✅ Тест успешно завершён')
  })

  test('форма показывает ошибки при пустой отправке шага 1', async ({ page }) => {
    await navigateToOrderPage(page)
    await page.locator('.btn-nav.btn-next').click()
    await expect(page.locator('input[placeholder="Иван Иванов"]')).toBeVisible({ timeout: 3000 })
  })
})